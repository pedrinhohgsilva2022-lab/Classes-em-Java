abstract class transporte{
    public abstract void mover();
}
class van extends transporte{
    @Override
    public void mover() {
        System.out.println("veiculo esta se movendo para cotia.");
    }
}
public class Ex05ClasseAbstrata {
    public static void main(String[] args) {
        transporte transporte = new van();
        transporte.mover();
    }
}
