sealed class Forma permits Circulo, Quadrado{
    public void tipos(){
        System.out.println("Existem varias formas. Dentre elas, há o quadrado e o circulo.");
    }
}
final class Circulo extends Forma{
    public void tipoCirculo(){
        System.out.println("Circulo: Uma forma totalmente redonda, sem vertice em sua estrutura.");
    }
}
final class Quadrado extends Forma{
    public void tipoQuadrado(){
        System.out.println("Quadrado: Possui seus 4 lados idênticos");
    }
}
public class Ex01ClassSealed {
    public static void main(String[] args) {
        Circulo c = new Circulo();
        c.tipos();
        c.tipoCirculo();
        Quadrado q = new Quadrado();
        q.tipoQuadrado();
    }
}