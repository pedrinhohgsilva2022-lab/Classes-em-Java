record Cidade(String nome, String estado) {
}

public class Ex02ClasseRecord {
    public static void main(String[] args) {

        Cidade cidade = new Cidade("Ibiúna", "SP");

        System.out.println("Cidade: " + cidade.nome());
        System.out.println("Estado: " + cidade.estado());
    }
}
