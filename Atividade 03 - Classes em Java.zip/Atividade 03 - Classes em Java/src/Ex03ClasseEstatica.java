class EmpresaTI {

    static class Setor {
        private String nome;

        public Setor(String nome) {
            this.nome = nome;
        }

        public void mostrar() {
            System.out.println("Departamento: " + nome);
        }
    }
}

public class Ex03ClasseEstatica {
    public static void main(String[] args) {

        EmpresaTI.Setor setor =
                new EmpresaTI.Setor("Desenvolvimento WEB");

        setor.mostrar();
    }
}
