class conta{
    private String numero;
    private String saldo;

    public conta(String numero, String saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }
     public void depositar(){
         System.out.println("Numero da conta: " + numero + ", Saldo: " + saldo);
     }
}

public class Ex02ClasseConcreta {
    public static void main(String[] args){
        conta c = new conta("567869-0", "R$12,672");
        c.depositar();
    }
}
