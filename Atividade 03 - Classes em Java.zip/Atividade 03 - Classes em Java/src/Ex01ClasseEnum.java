enum DiaDaSemana {
    SEGUNDA,
    TERCA,
    QUARTA,
    QUINTA,
    SEXTA,
    SABADO,
    DOMINGO
}

public class Ex01ClasseEnum {
    public static void main(String[] args) {

        DiaDaSemana dias = DiaDaSemana.DOMINGO;

        System.out.println("Dia selecionado: " + dias);
    }
}
