record Usuario(String login, String senha) {
}
public class Ex05ClasseRecord {
    public static void main(String[] args) {
        Usuario user = new Usuario("Pedro.hg@hotmail.com", "senhaTeste123");
        System.out.println("Seu login: " + user.login());
        System.out.println("Sua senha: " + user.senha());
        System.out.println(user);
    }
}
