enum StatusTarefa {
    PENDENTE,
    PROCESSANDO,
    CONCLUIDA
}

public class Ex03ClasseEnum {
    public static void main(String[] args) {

        StatusTarefa status = StatusTarefa.PROCESSANDO;

        System.out.println("Status: " + status);
    }
}
