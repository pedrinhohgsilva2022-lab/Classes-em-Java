final class constantesApp{
    private String nomesistema = "Free fire";
    public void mostrarNomesistema(){
        System.out.println("Aplicativo: " + nomesistema);
    }
}
public class Ex02ClasseFinal {
    public static void main(String[] args) {
        constantesApp app = new constantesApp();
        app.mostrarNomesistema();
    }
}
