final class constantesApp{
    private String nomesistema = "instagram";
    public void mostrarNomesistema(){
        System.out.println("Nome do sistema: " + nomesistema);
    }
}
public class Ex02ClasseFinal {
    public static void main(String[] args) {
        constantesApp app = new constantesApp();
        app.mostrarNomesistema();
    }
}
