final class validarCPF{
    private String cpf = "400.289.222-10";
    public void validar(){
        System.out.println("CPF válido: " + cpf );
    }
}
public class Ex03ClasseFinal {
    public static void main(String[] args) {
        validarCPF cpf = new validarCPF();
        cpf.validar();
    }
}
