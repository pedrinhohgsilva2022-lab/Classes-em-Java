enum CorSemaforo {
    VERMELHO,
    AMARELO,
    VERDE
}

public class Ex04ClasseEnum {
    public static void main(String[] args) {

        CorSemaforo cor = CorSemaforo.VERDE;

        System.out.println("Cor atual: " + cor);
    }
}
