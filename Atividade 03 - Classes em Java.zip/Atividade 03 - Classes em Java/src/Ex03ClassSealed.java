sealed class Midia permits LivroDigital, Video{
    public void tipos(){
        System.out.println("Quando falamos de Midías, abrangemos diversos tipos dela. Dentre as principais, estão os videos e os livros digitais.");
    }
}
final class LivroDigital extends Midia{
    public void tipoEBook(){
        System.out.println("Livro Digital: Ou e-book, como é mais conhecido, foca na leitura e atenção ao conteúdo apresentado.");
    }
}
final class Video extends Midia{
    public void tipoVideo(){
        System.out.println("Video: Ao contrário do e-book, o video foca no estimulo visual e absorção rápida do conteúdo.");
    }
}
public class Ex03ClassSealed {
    public static void main(String[] args) {
        LivroDigital eB = new LivroDigital();
        eB.tipos();
        eB.tipoEBook();
        Video v = new Video();
        v.tipoVideo();
    }
}