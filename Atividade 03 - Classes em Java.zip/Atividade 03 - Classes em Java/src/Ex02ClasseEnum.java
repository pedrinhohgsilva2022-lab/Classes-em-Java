enum NivelAcesso {
    ADMIN,
    GERENTE,
    USUARIO
}

public class Ex02ClasseEnum {
    public static void main(String[] args) {

        NivelAcesso nivel = NivelAcesso.ADMIN;

        System.out.println("Nível de acesso: " + nivel);
    }
}
