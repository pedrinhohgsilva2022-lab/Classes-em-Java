enum NivelAcesso {
    Administrador,
    Desenvolvedor,
    Usuário;
}

public class Ex02ClasseEnum {
    public static void main(String[] args) {

        NivelAcesso nivel = NivelAcesso.Administrador;

        System.out.println("Nível de acesso: " + nivel);
    }
}
