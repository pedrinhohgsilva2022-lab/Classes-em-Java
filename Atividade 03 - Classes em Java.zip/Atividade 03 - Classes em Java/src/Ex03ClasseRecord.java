record Filme(String titulo, int ano) {
}

public class Ex03ClasseRecord {
    public static void main(String[] args) {

        Filme filme = new Filme("Vingadores", 2019);

        System.out.println("Título: " + filme.titulo());
        System.out.println("Ano: " + filme.ano());
    }
}