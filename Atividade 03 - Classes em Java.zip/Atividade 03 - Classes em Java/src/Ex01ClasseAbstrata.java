abstract class Animal {
    public abstract void emitirSom();
}

class Cachorro extends Animal {
    @Override
    public void emitirSom() {
        System.out.println("Au au");
    }
}

public class Ex01ClasseAbstrata {
    public static void main(String[] args) {
        Cachorro dog = new Cachorro();
        dog.emitirSom();
    }
}
