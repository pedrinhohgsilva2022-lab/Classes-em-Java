record Produto(String nome, double preco) {
}

public class Ex01ClasseRecord {
    public static void main(String[] args) {

        Produto p = new Produto("Bola de futsal", 149.99);

        System.out.println("Produto: " + p.nome());
        System.out.println("Preço: R$" + p.preco());
    }
}