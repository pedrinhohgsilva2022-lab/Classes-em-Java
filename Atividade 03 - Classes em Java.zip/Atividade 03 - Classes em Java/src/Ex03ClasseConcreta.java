class carro{
    private String marca;
    private String modelo;
    public carro(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }
    public void exibir(){
        System.out.println("Marca: " + marca + ", Modelo do veiculo: " + modelo);
    }
}
public class Ex03ClasseConcreta{
    public static void main(String[] args){
        carro c = new carro("Volkswagen", "Gol GTI");
        c.exibir();
    }
}
