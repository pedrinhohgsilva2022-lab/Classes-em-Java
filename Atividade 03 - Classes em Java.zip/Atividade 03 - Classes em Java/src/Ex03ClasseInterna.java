class Banco {
    private String nomeBanco;

    public Banco(String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }

    class Agencia {
        private int numero;

        public Agencia(int numero) {
            this.numero = numero;
        }

        public void mostrarDados() {
            System.out.println("Banco: " + nomeBanco);
            System.out.println("Agência: " + numero);
        }
    }
}

public class Ex03ClasseInterna {
    public static void main(String[] args) {
        Banco instituicao = new Banco("Banco do bradesco");
        Banco.Agencia agencia = instituicao.new Agencia(1009872);

        agencia.mostrarDados();
    }
}
