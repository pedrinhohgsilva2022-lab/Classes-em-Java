class casa{
    private String endereco;
    public casa(String endereco){
        this.endereco = endereco;
    }
    class quarto{
        private String nome;
        public quarto(String nome){
            this.nome = nome;
        }
        public void mostardados(){
            System.out.println("Logradouro da casa: " + endereco);
            System.out.println("Comôdo: " + nome);
        }
    }
}
public class Ex01ClasseInterna {
    public static void main(String[] args) {
        casa casa = new casa("Avenida escola politécnica, 1551");
        casa.quarto quarto =  casa.new quarto("Sala de estar");
        quarto.mostardados();
    }
}
