interface Alarme {
    void tocar();
}

public class Ex04ClasseAnonima {
    public static void main(String[] args) {

        Alarme alarme = new Alarme() {
            @Override
            public void tocar() {
                System.out.println("Alarme disparado!");
            }
        };

        alarme.tocar();
    }
}
