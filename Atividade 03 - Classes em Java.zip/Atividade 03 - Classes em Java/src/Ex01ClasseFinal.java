final class versaoSistema{
    private String versao = "v1.59";
    public void mostrarversão(){
        System.out.println("Sua versão atual é: " + versao);
    }
}
public class Ex01ClasseFinal {
    public static void main(String[] args) {
        versaoSistema versaoFinal= new versaoSistema();
        versaoFinal.mostrarversão();
    }
}
