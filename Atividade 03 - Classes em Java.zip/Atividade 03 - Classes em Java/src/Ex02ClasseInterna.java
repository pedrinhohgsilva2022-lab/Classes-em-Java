class Escola {
    private String nomeEscola;

    public Escola(String nomeEscola) {
        this.nomeEscola = nomeEscola;
    }

    class Turma {
        private String nomeTurma;

        public Turma(String nomeTurma) {
            this.nomeTurma = nomeTurma;
        }

        public void mostrarDados() {
            System.out.println("Instituição de ensino: " + nomeEscola);
            System.out.println("Turma: " + nomeTurma);
        }
    }
}

public class Ex02ClasseInterna {
    public static void main(String[] args) {
        Escola escola = new Escola("EMEF João XXIII");
        Escola.Turma turma = escola.new Turma("3º ano do fundamental");

        turma.mostrarDados();
    }
}
