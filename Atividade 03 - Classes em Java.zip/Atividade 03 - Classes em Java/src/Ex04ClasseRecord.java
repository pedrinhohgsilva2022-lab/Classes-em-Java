record Coordenada(int x, int y) {
}

public class Ex04ClasseRecord {
    public static void main(String[] args) {

        Coordenada ponto = new Coordenada(10, 20);

        System.out.println("X = " + ponto.x());
        System.out.println("Y = " + ponto.y());
    }
}
