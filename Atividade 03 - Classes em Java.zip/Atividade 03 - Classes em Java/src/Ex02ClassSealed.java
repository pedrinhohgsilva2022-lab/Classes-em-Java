sealed class Contas permits ContaCorrente, ContaPoupanca{
    public void tiposConta(){
        System.out.println("Há dois tipos de conta, sendo eles corrente e poupança.");
    }
}
final class ContaCorrente extends Contas{
    public void Corrente(){
        System.out.println("Corrente: Focado no dia a dia, receber salários e pagar contas.");
    }
}
final class ContaPoupanca extends Contas{
    public void Poupanca(){
        System.out.println("Poupança: Conta pensada à longo prazo; focada para guardar dinheiro, mas sem investir diretamente.");
    }
}
public class Ex02ClassSealed {
    public static void main(String[] args) {
        ContaCorrente c = new ContaCorrente();
        c.tiposConta();
        c.Corrente();
        ContaPoupanca q = new ContaPoupanca();
        q.Poupanca();
    }
}