class Livro {
    private String autor;
    private String titulo;
    public Livro(String autor, String titulo){
        this.autor = autor;
        this.titulo = titulo;
    }
    public void mostrardados(){
        System.out.println("autor: " + autor + ", titulo: " + titulo);
    }
}
class Ex01ClasseConcreta {
    public static void main(String[] args){
        Livro info = new Livro("Ana","nas mãos de maria");
        info.mostrardados();
    }
}