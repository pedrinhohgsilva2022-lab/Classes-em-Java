class Livro {
    private String autor;
    private String titulo;
    public Livro(String autor, String titulo){
        this.autor = autor;
        this.titulo = titulo;
    }
    public void mostrardados(){
        System.out.println("Autor: " + autor + ", Titulo: " + titulo);
    }
}
class Ex01ClasseConcreta {
    public static void main(String[] args){
        Livro info = new Livro("Conceição Evaristo","Olhos d'água");
        info.mostrardados();
    }
}