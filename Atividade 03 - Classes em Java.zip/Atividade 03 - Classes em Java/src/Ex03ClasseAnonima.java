class pessoa {
}

public class Ex03ClasseAnonima {
    public static void main(String[] args) {

        pessoa p = new pessoa() {
            @Override
            public String toString() {
                return "Objeto people criado utilizando uma classe anônima.";
            }
        };

        System.out.println(p);
    }
}
