public class Ex05ClasseAnonima {
    public static void main(String[] args) {

        Runnable tarefa = new Runnable() {
            @Override
            public void run() {
                System.out.println("Executando tarefa...");
            }
        };

        tarefa.run();
    }
}
